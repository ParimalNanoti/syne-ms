package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Product;
import com.service.ProductService;

@RestController
@RefreshScope
@RequestMapping("/products")
public class ProductController {
	@Value("${spring.appname}")
	 String message;
	@Autowired
	private ProductService service;
	@PostMapping("/addproducts")
	public Product addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}
	@GetMapping("/getproducts")
	public List<Product> getProducts(){
		System.out.println("Message from prop "+ message);
		return service.getProducts();
		
	}
	@GetMapping("/getproducts/{productsidList}")
	public List<Product>getProductById(@PathVariable List<Long> productsidList){
		return service.getProductsByIds(productsidList);
	}

}
