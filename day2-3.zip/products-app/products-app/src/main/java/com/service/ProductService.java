package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.entity.Product;
import com.repo.ProductRepo;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepo productRepo;
	
	public Product addProduct(Product product) {
		return productRepo.save(product);
	}
public List<Product> getProducts(){
	return (List<Product>)productRepo.findAll();
}
public List<Product> getProductsByIds(List<Long> pList){
	return (List<Product>)productRepo.findAllById(pList);
}
}
