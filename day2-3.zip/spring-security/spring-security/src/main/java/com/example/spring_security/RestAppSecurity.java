package com.example.spring_security;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
 public class RestAppSecurity {
	@GetMapping("/welcome")
	public String welcome() {
		return "welcome";
	}
	@GetMapping("/home")
	public String home() {
		return "home";
	}
	@GetMapping("/admin")
	public String admin() {
		return "admin";
	}
	@GetMapping("/employee")
	public String emp() {
		return "employee";
	}
	@GetMapping("/manager")
	public String manager() {
		return "manager";
	}
	@GetMapping("/common")
	public String common() {
		return "common";
	}
}
